package com.example.admin.test2advanceanroid.adapters;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import model.Product;
import com.example.admin.test2advanceanroid.R;

/**
 * Created by admin on 8/13/2017.
 */

public class GuestAdapter extends BaseAdapter{

    private static LayoutInflater inflater = null;
    private ArrayList<Product> products;
    ImageView guestImageView;
    TextView txtGuesTitle, txtGuestPrice;
    CheckBox chkGuest;

    public GuestAdapter(Context context, ArrayList<Product> products){
        this.products = products;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return products.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;

        if(convertView == null) {
            view = inflater.inflate(R.layout.guest_list_row, null);
            txtGuesTitle = (TextView) view.findViewById(R.id.guestTitleTextView);
            txtGuestPrice = (TextView) view.findViewById(R.id.guestPriceTextView);
            guestImageView = (ImageView) view.findViewById(R.id.guestImageView);
            chkGuest = (CheckBox) view.findViewById(R.id.guestCheckBox);
            Product product = products.get(position);
            txtGuesTitle.setText(product.getTitle());
            guestImageView.setImageResource(product.getImageId());
            txtGuestPrice.setText("Price: " + product.getPrice());
            chkGuest.setChecked(false);
        }
        return view;
    }
}
