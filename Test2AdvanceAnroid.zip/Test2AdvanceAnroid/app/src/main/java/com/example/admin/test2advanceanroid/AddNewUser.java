package com.example.admin.test2advanceanroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import model.DbHelper;
import model.NewUserFormHelper;
import model.User;

public class AddNewUser extends AppCompatActivity {

    EditText saveEmail, savePassword, savePhone;
    Button btnSave;
    private NewUserFormHelper helper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_user);
        setTitle("New User");

        saveEmail = (EditText) findViewById(R.id.saveEmail);
        savePassword = (EditText) findViewById(R.id.savePassword);
        savePhone = (EditText) findViewById(R.id.savePhone);
        btnSave = (Button) findViewById(R.id.save);

        helper = new NewUserFormHelper(AddNewUser.this);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String email = saveEmail.getText().toString().trim();

                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                if (email.matches(emailPattern))
                {
                    User user = helper.helperUser();
                    DbHelper database = new DbHelper(AddNewUser.this);
                    if (database.dbAddUser(user)) {
                        Toast.makeText(AddNewUser.this, "Saved", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(AddNewUser.this, "Email already registered", Toast.LENGTH_SHORT).show();
                    }
                    
                    database.close();

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Invalid email address", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
