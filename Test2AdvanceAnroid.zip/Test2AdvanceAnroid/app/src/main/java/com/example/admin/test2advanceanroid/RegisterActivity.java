package com.example.admin.test2advanceanroid;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.test2advanceanroid.adapters.GuestAdapter;
import com.example.admin.test2advanceanroid.adapters.RegisteredAdapter;

import java.util.ArrayList;

import model.DbHelper;
import model.Product;
import model.ProductArrayListClass;

public class RegisterActivity extends AppCompatActivity {
    ImageView regImageView;
    TextView txtRegTitle, txtWelcome;
    EditText edtRegPrice, edtRegDiscont;
    CheckBox chkReg;
    String smsString;

    ListView lstRegister;
    private Button amountBtn, smsBtn, saveAmtBtn, showAmtBtn;
    ArrayList<Product> products;
    double amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        regImageView = (ImageView) findViewById(R.id.regImageView);
        txtRegTitle = (TextView) findViewById(R.id.regTitleTextView);
//        edtRegPrice = (EditText) findViewById(R.id.edtRegPrice);
//        edtRegDiscont = (EditText) findViewById(R.id.edtRegDisc);
//        chkReg = (CheckBox) findViewById(R.id.regCheckBox);
        amountBtn = (Button) findViewById(R.id.btnTotalAmount);
        smsBtn = (Button) findViewById(R.id.btnSendSms);
        txtWelcome = (TextView) findViewById(R.id.welcomeText);
        saveAmtBtn = (Button) findViewById(R.id.btnSaveAmount);
        showAmtBtn = (Button) findViewById(R.id.btnShowAmounts);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String title = sharedPreferences.getString("email", null);
        txtWelcome.setText("Welcome, " + title);

        lstRegister = (ListView) findViewById(R.id.regList);

        RegisteredAdapter adapter = new RegisteredAdapter(RegisterActivity.this, ProductArrayListClass.products);
        lstRegister.setAdapter(adapter);

        amountBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcAmount();
            }
        });

        saveAmtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkBoxStatus()) {
                    calcAmount();
                    DbHelper db = new DbHelper(RegisterActivity.this);
                    db.dbAmountInsert(amount, RegisterActivity.this);
                    db.close();
                    Toast.makeText(RegisterActivity.this, "Amount saved", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(RegisterActivity.this, "Please select at least one product", Toast.LENGTH_SHORT).show();
                }
            }
        });

        showAmtBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, AmountFatchActivity.class);
                startActivity(intent);
            }
        });



        smsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sendIntent = new Intent(Intent.ACTION_VIEW);
                setSMS();
                sendIntent.putExtra("sms_body", smsString);
                sendIntent.setType("vnd.android-dir/mms-sms");
                startActivity(sendIntent);
            }
        });

    }

    public void setSMS(){
        smsString = "";
        String priceSend, discountSend, titleProduct;
        EditText actualPrice, discountPrice;
        CheckBox checkBoxSms;
        TextView titleName;
        for (int i = 0; i < lstRegister.getCount(); i++) {
            View child = lstRegister.getChildAt(i);
            actualPrice = (EditText) child.findViewById(R.id.edtRegPrice);
            discountPrice = (EditText) child.findViewById(R.id.edtRegDisc);
            titleName = (TextView) child.findViewById(R.id.regTitleTextView);
            checkBoxSms = (CheckBox) child.findViewById(R.id.regCheckBox);
            priceSend = actualPrice.getText().toString();
            discountSend = discountPrice.getText().toString();
            titleProduct = titleName.getText().toString();
            if(checkBoxSms.isChecked()){
                if (smsString.isEmpty()){
                    if(discountSend.isEmpty()){
                        smsString = smsString +"Great Sale promotion here\n" + titleProduct + " Price $" +  priceSend;
                    }
                    else {
                        smsString = smsString +"Great Sale promotion here\n" + titleProduct + " Price $" +  priceSend + " Discount " + discountSend + "%";
                    }
                }else{
                    if(discountSend.isEmpty()){
                        smsString = smsString +"\n" + titleProduct + " Price $" +  priceSend;
                    }
                    else {
                        smsString = smsString +"\n" + titleProduct + " Price $" +  priceSend + " Discount " + discountSend + "%";
                    }
                }
            }


        }
        calcAmount();
        smsString = smsString + "\nAmount $" + amount;

    }

    private void calcAmount() {
        amount = 0;
        EditText priceText, discountText;
        CheckBox checkBox;
        double price, discount;
        for (int i = 0; i < lstRegister.getCount(); i++) {
            View child = lstRegister.getChildAt(i);
            priceText = (EditText) child.findViewById(R.id.edtRegPrice);
            discountText = (EditText) child.findViewById(R.id.edtRegDisc);
            checkBox = (CheckBox) child.findViewById(R.id.regCheckBox);
            price = Double.parseDouble(priceText.getText().toString());


                try {
                    discount = Double.parseDouble(discountText.getText().toString());
                } catch (NumberFormatException e) {
                    discount = 0;
                }
                if (checkBox.isChecked()) {
                    amount = amount + (price - (price * discount / 100));
                }


        }
        amountBtn.setText("Amount: $" + amount);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_register_activity, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.menu_logout:

                SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(RegisterActivity.this);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.remove("email");
                editor.commit();
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private boolean checkBoxStatus() {
        for (int i = 0; i < lstRegister.getCount(); i++) {
            View v = lstRegister.getChildAt(i);
            CheckBox checkBox = (CheckBox) v.findViewById(R.id.regCheckBox);
            if (checkBox.isChecked()) {
                return true;
            }
        }
        return false;
    }


}
