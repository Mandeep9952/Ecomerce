package com.example.admin.test2advanceanroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.test2advanceanroid.adapters.GuestAdapter;

import java.util.ArrayList;

import model.Product;
import model.ProductArrayListClass;

public class GuestActivity extends AppCompatActivity {

    ListView lstGuest;
    ArrayList<Product> products;
    Button btnGuestAmountTotal;
    double amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);

        products = ProductArrayListClass.products;
        lstGuest = (ListView) findViewById(R.id.guestList);
        btnGuestAmountTotal = (Button) findViewById(R.id.guestTotalAmount);

        GuestAdapter adapter = new GuestAdapter(GuestActivity.this, ProductArrayListClass.products);
        lstGuest.setAdapter(adapter);

        btnGuestAmountTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcAmount();
            }
        });

    }
    private void calcAmount() {
        amount = 0;
        TextView guestPrice;
        CheckBox checkBox;
        double price, discount;
        for (int i = 0; i < lstGuest.getCount(); i++) {
            View child = lstGuest.getChildAt(i);
            guestPrice = (TextView) child.findViewById(R.id.guestPriceTextView);
            checkBox = (CheckBox) child.findViewById(R.id.guestCheckBox);
           // price = Double.parseDouble(guestPrice.getText().toString());
            String hallostring = guestPrice.getText().toString();
            String asubstring = hallostring.substring(7);


//            try {
//                discount = Double.parseDouble(discountText.getText().toString());
//            } catch (NumberFormatException e) {
//                discount = 0;
//            }
            if (checkBox.isChecked()) {
                amount =  amount + Double.parseDouble(asubstring);
            }
//            else{
//                Toast.makeText(this, "wrong", Toast.LENGTH_SHORT).show();
//            }


        }
        btnGuestAmountTotal.setText("Amount: $" + amount);
    }
    }

