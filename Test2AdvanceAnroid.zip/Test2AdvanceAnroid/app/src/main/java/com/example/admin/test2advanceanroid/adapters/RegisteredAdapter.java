package com.example.admin.test2advanceanroid.adapters;

import android.content.Context;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.test2advanceanroid.R;

import java.util.ArrayList;

import model.Product;

import static com.example.admin.test2advanceanroid.R.id.guestImageView;
import static com.example.admin.test2advanceanroid.R.id.regImageView;

/**
 * Created by admin on 8/13/2017.
 */

public class RegisteredAdapter extends BaseAdapter {

    private static LayoutInflater inflater = null;
    private ArrayList<Product> products;
    ImageView regImageView;
    TextView txtRegTitle, txtRegPrice, txtRegDiscount;
    EditText edtRegPrice, edtRegDiscount;
    CheckBox chkReg;

    public RegisteredAdapter(Context context, ArrayList<Product> products) {
        this.products = products;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return products.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = convertView;

        if(convertView == null) {
            view = inflater.inflate(R.layout.registered_list_row, null);
            txtRegTitle = (TextView) view.findViewById(R.id.regTitleTextView);
            txtRegPrice = (TextView) view.findViewById(R.id.txtprice);
            txtRegDiscount = (TextView) view.findViewById(R.id.txtdisc);
            regImageView = (ImageView) view.findViewById(R.id.regImageView);
            edtRegPrice = (EditText) view.findViewById(R.id.edtRegPrice);
            edtRegDiscount = (EditText) view.findViewById(R.id.edtRegDisc);
            chkReg = (CheckBox) view.findViewById(R.id.regCheckBox);
            Product product = products.get(position);
            txtRegTitle.setText(product.getTitle());
            regImageView.setImageResource(product.getImageId());
            edtRegPrice.setText(String.valueOf(product.getPrice()));
            chkReg.setChecked(false);
        }
        return view;

    }
}
