package com.example.admin.test2advanceanroid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import model.DbHelper;

public class AmountFatchActivity extends AppCompatActivity {
    ListView lstAmountFatch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amount_fatch);

        lstAmountFatch = (ListView) findViewById(R.id.amountFatchList);
        DbHelper db = new DbHelper(AmountFatchActivity.this);
        ArrayList<String> amountList = db.dbGetAmountList(AmountFatchActivity.this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, amountList);
        lstAmountFatch.setAdapter(adapter);
    }
}
