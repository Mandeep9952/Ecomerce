package model;

import android.widget.EditText;
import android.widget.RatingBar;

import com.example.admin.test2advanceanroid.AddNewUser;
import com.example.admin.test2advanceanroid.R;

/**
 * Created by admin on 8/13/2017.
 */

public class NewUserFormHelper {

    private final EditText fieldEmail;
    private final EditText fieldPassword;
    private final EditText fieldPhone;
    private User user;

    public NewUserFormHelper(AddNewUser activity) {

        fieldEmail = (EditText) activity.findViewById(R.id.saveEmail);
        fieldPassword = (EditText) activity.findViewById(R.id.savePassword);
        fieldPhone = (EditText) activity.findViewById(R.id.savePhone);
        user = new User();
    }

    public User helperUser() {
        user.setEmail(fieldEmail.getText().toString());
        user.setPassword(fieldPassword.getText().toString());
        user.setPhone(fieldPhone.getText().toString());

        return user;
    }

}


