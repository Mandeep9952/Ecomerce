package model;

/**
 * Created by admin on 8/13/2017.
 */

public class Product {
    private String title;
    private int imageId;
    private double price, discount;

    public Product(String title, int imageId, double price) {
        this.title = title;
        this.imageId = imageId;
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
}
