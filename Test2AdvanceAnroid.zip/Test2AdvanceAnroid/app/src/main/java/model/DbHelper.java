package model;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.preference.PreferenceManager;

import java.util.ArrayList;

/**
 * Created by admin on 8/13/2017.
 */

public class DbHelper extends SQLiteOpenHelper {

    public DbHelper(Context context) {
        super(context, "c0700809_USERACCESS", null, 2);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE Users (id INTEGER PRIMARY KEY, email TEXT, password TEXT, phone TEXT)";
        String sql1 = "CREATE TABLE AmountsListTable (id INTEGER PRIMARY KEY, amount REAL, email TEXT)";
        db.execSQL(sql);
        db.execSQL(sql1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE IF EXISTS Users";
        String sql1 = "DROP TABLE IF EXISTS AmountsListTable";
        db.execSQL(sql);
        db.execSQL(sql1);
        onCreate(db);

    }

    public boolean dbAddUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "SELECT * FROM Users WHERE email = '" + user.getEmail() + "'";
        Cursor c = db.rawQuery(sql, null);
        if (c.getCount() > 0) {
            return false;
        }
        ContentValues userData = new ContentValues();
        userData.put("email", user.getEmail());
        userData.put("password", user.getPassword());
        userData.put("phone", user.getPhone());


        db.insert("Users", null, userData);
        return true;
    }

    public void dbAmountInsert(double amount, Context context) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues amountData = new ContentValues();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String email = sharedPreferences.getString("email", null);
        amountData.put("amount", amount);
        amountData.put("email", email);
        db.insert("AmountsListTable", null, amountData);
    }

    public ArrayList<String> dbGetAmountList(Context context) {
        ArrayList<String> amountArrayList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        String email = sharedPreferences.getString("email", null);
        Cursor c = db.rawQuery("SELECT * FROM AmountsListTable WHERE email = '" + email + "'", null);
        int i = 1;
        while (c.moveToNext()) {
            double amount = c.getDouble(c.getColumnIndex("amount"));
            amountArrayList.add(i + " - " + amount);
            i++;
        }

        return amountArrayList;
    }

    public boolean validateLogin(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM Users WHERE email = '" + email + "' AND password = '" + password + "'";
        Cursor c = db.rawQuery(sql, null);
        if (c.getCount() > 0) {
            return true;
        }
        return false;
    }



    //insert

}
