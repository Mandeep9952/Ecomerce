package model;

import java.util.ArrayList;
import com.example.admin.test2advanceanroid.R;

/**
 * Created by admin on 8/14/2017.
 */

public class ProductArrayListClass {

    private static ArrayList<Product> initialize() {
        ArrayList<Product> products = new ArrayList<>();
        products.add(new Product("One Piece", R.drawable.one_piece, 35.45));
        products.add(new Product("Scarf", R.drawable.scarf, 10.99));
        products.add(new Product("Skirt", R.drawable.skirt, 24.50));
        return products;
    }

    public static ArrayList<Product> products = initialize();
}
