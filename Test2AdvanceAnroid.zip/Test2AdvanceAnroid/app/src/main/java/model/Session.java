package model;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created by admin on 8/14/2017.
 */

public class Session {

    public void setSession(String email, SharedPreferences sharedPreferences) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("email", email);
        editor.commit();
    }

}
